<?php session_start('test'); ?>
<!DOCTYPE html PUBLIC "-//W3C/DTD XHTML 1.1//EN"
	"http://www.w3.org/ter/xhtml11/DTD/xhtml11.dtd">
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="stylesheet.css">
			<script type="text/javascript">
				function showTopic(str)
				{
				if (str=="")
				  {
				  document.getElementById("topicTabel").innerHTML="";
				  return;
				  } 
				if (window.XMLHttpRequest)
				  {// code for IE7+, Firefox, Chrome, Opera, Safari
				  xmlhttp=new XMLHttpRequest();
				  }
				else
				  {// code for IE6, IE5
				  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
				  }
				xmlhttp.onreadystatechange=function()
				  {
				  if (xmlhttp.readyState==4 && xmlhttp.status==200)
					{
					document.getElementById("topicTabel").innerHTML=xmlhttp.responseText;
					}
				  }
				xmlhttp.open("GET","adminphp.php?q="+str,true);
				xmlhttp.send();
				}
			</script>
			<title>
				<?php include 'forumname.php'; ?>
			</title>
	</head>
	<body>
		<div class="container">
			<div class="header">
				<?php include 'header.php'; ?>
			</div>
			<div class="menu">
				<?php include 'menu.php'; ?>
			</div>
			<div class="slidemenu">
				<?php include 'adminslide.php'; ?>
			</div>
			<div class="center">
			<?php 
				if (array_key_exists('admin',$_SESSION) && ($_SESSION['admin']) != "" && $_SESSION['admin'] == 1)
					echo "<form>
					<select name='users' onchange='showTopic(this.value)'>
					<option value=''>Select Posts Type:</option>
					<option value='0'>Pending Posts</option>
					<option value='1'>Approved Posts</option>
					</select>
					</form>
					<br />
					<div id='topicTabel'> Selected Posts will be displayed here.</div>";
				else
					echo "You are not an admin.";
				?>
			</div>
			<div class="footer">
				&#169; 2012 <?php include 'forumname.php'; ?>
			</div>
		</div>
	</body>
</html>
