<?php 
	echo "<a href='adminpagecat.php'>Catagory Administration</a><br />
		<a href='adminpage.php'>Posts Administration</a><br />
		<a href='adminfaq.php'>FAQ Administration</a><br />"; 
?>