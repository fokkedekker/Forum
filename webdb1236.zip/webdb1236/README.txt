Projectgroep: webdb1236

Projectnaam: Gitmasters

Namen - Studentennummers:
Michiel Mosmans - 10072896
Fokke Dekker - 10264256
Kees Halvemaan - 10188010
Hamid Chaman - ????????

Verklaring van samenwerking:
Michiel Mosmans, Fokke Dekker en Kees Halvemaan verklaren hierbij dat de samenwerking met elkaar goed verlopen is.
De samenwerking met Hamid Chaman is niet goed verlopen, hier is over gesproken met de begeleider (Sander) en de docent (meneer Belleman).

Url:
https://websec.science.uva.nl/webdb1236/index.php
(Admin)
1.Gebruikersnaam: fokke
1.Wachtwoord: fokke
(User)
2.Gebruikersnaam: pietje
2.Wachtwoord: pietje